<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Verity</b>
      </div>
      <strong> &copy; 2020 Powered By<a href="https://web.facebook.com/fortisafrica"> FORTIS AFRICA</a></strong>
    </div>
    <!-- /.container -->
</footer>