<?php
	$conn = new mysqli('localhost', 'cedipay4_verity', 'Verity@2020', 'cedipay4_votesystem');

	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	
?>